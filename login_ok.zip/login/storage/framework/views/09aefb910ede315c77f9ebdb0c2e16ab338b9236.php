<!DOCTYPE html>
<html>
<head>
<title>Forgot Password Email</title>
</head>
<body>
<h2>Hi <?php echo e($user['name']); ?></h2>
<br/>
    You has just request to change password, Please click on the below link to reset your password
<br/>
<a href="<?php echo e(url('api/user/verify', $user->remember_token)); ?>">Reset Password</a>
</body>
</html>
