<!DOCTYPE html>
<html>
<head>
<title>Activation Email</title>
</head>
<body>
<h2>Welcome to the site <?php echo e($user['name']); ?></h2>
<br/>
Your registered email-id is <?php echo e($user['email']); ?> , Please click on the below link to verify your email account
<br/>
<a href="<?php echo e(url('api/user/verify', $user->remember_token)); ?>">Verify Account</a>
</body>
</html>
