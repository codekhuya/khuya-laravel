<!DOCTYPE html>
<html>
<head>
<title>Welcome To Website</title>
</head>
<body>
<h2>Welcome to our website, {{$user['name']}}</h2>
<br/>
    Your registered email-id is {{$user['email']}}
<br/>
<h2>Enjoy your time in our webstie :D</h2>
</body>
</html>
